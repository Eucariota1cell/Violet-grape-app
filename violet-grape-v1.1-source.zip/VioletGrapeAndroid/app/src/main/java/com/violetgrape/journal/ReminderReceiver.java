package com.violetgrape.journal;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class ReminderReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        ReminderScheduler.ensureChannel(context);

        String id = intent.getStringExtra("id");
        if (id == null || id.trim().isEmpty()) return;
        String title = intent.getStringExtra("title");
        String body = intent.getStringExtra("body");
        int hour = intent.getIntExtra("hour", 9);
        int minute = intent.getIntExtra("minute", 0);
        int day = intent.getIntExtra("day", 2);

        Intent open = new Intent(context, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent contentIntent = PendingIntent.getActivity(
                context,
                id.hashCode() & 0x7fffffff,
                open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Notification notification = new Notification.Builder(context, ReminderScheduler.CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(title == null || title.trim().isEmpty() ? "Violet Grape" : title)
                .setContentText(body == null || body.trim().isEmpty() ? "Un recordatorio que dejaste para ti 💜" : body)
                .setContentIntent(contentIntent)
                .setAutoCancel(true)
                .build();

        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify((id + ":" + day).hashCode() & 0x7fffffff, notification);

        // Reprograma el mismo día para la semana siguiente.
        ReminderScheduler.schedule(context, id, title, body, hour, minute, day);
    }
}
