# Violet Grape Android v1.0

Violet Grape es un journal local de bienestar para Android. La app no necesita servidor, cuenta ni conexión a Internet para funcionar.

## Privacidad
- El WebView tiene bloqueadas las cargas de red.
- Los registros se guardan en el almacenamiento privado interno de la app.
- `android:allowBackup="false"` evita el backup automático del sistema de la base local.
- Puede configurarse un PIN local de 4–8 dígitos.
- En Android 9+ puede activarse desbloqueo biométrico si el dispositivo lo soporta.
- La copia manual exportada es JSON sin cifrar; debe guardarse en un lugar privado.

## Funciones incluidas
- Dashboard “Hoy” en tonos lilas con arte de uvas/acuarela.
- Registro de comidas, porciones, calorías aproximadas y proteína opcional.
- Alimentos frecuentes editables.
- Registro visual de agua.
- Generador de menús flexible, rápido, sin carne o con quesadillas.
- Registro de peso y gráfica de tendencia.
- Journal de ánimo, hambre, energía, relación con el cuerpo y notas.
- Metas configurables de peso, agua y referencia de calorías.
- PIN, biometría, exportación e importación de respaldo.

## Arquitectura
La interfaz está empaquetada dentro del APK en `app/src/main/assets/index.html`; no se publica como sitio web. Un contenedor Android nativo (`MainActivity.java`) controla el almacenamiento privado, el bloqueo y los respaldos.

## Build
El proyecto incluye `.github/workflows/build-apk.yml`. En GitHub Actions el APK de prueba se genera como artefacto `Violet-Grape-v1-debug`.

Paquete: `com.violetgrape.journal`
Min SDK: 28
Target SDK: 35
