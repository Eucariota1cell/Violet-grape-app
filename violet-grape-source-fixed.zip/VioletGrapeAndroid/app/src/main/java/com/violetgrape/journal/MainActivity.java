package com.violetgrape.journal;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.hardware.biometrics.BiometricPrompt;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.provider.Settings;
import android.text.InputType;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.concurrent.Executor;

public class MainActivity extends Activity {
    private static final int REQ_EXPORT = 3201;
    private static final int REQ_IMPORT = 3202;
    private static final String PREFS = "violet_grape_secure";
    private static final String DATA_FILE = "violet_grape_data.json";

    private WebView webView;
    private SharedPreferences prefs;
    private String pendingExportJson;
    private boolean appUnlocked = false;
    private long pausedAt = 0L;
    private boolean showingUnlock = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        styleSystemBars();
        setupWebView();

        if (hasLockConfigured()) {
            showUnlockFlow();
        } else {
            unlockAndLoad();
        }
    }

    private void styleSystemBars() {
        Window w = getWindow();
        w.setStatusBarColor(Color.rgb(247, 242, 250));
        w.setNavigationBarColor(Color.rgb(250, 247, 252));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
    }

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    private void setupWebView() {
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(250, 247, 252));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBlockNetworkLoads(true); // Violet Grape is intentionally offline-only.
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        settings.setTextZoom(100);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return !url.startsWith("file:///android_asset/");
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new NativeBridge(this), "VioletNative");
        setContentView(webView);
    }

    private boolean hasLockConfigured() {
        return prefs.contains("pin_hash") || prefs.getBoolean("biometric_enabled", false);
    }

    private void unlockAndLoad() {
        showingUnlock = false;
        appUnlocked = true;
        if (webView.getUrl() == null) {
            webView.loadUrl("file:///android_asset/index.html");
        } else {
            webView.onResume();
        }
    }

    private void showUnlockFlow() {
        if (showingUnlock) return;
        showingUnlock = true;
        appUnlocked = false;
        boolean bio = prefs.getBoolean("biometric_enabled", false);
        if (bio && Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            tryBiometric();
        } else if (prefs.contains("pin_hash")) {
            showPinDialog();
        } else {
            showingUnlock = false;
            unlockAndLoad();
        }
    }

    private void tryBiometric() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
            showPinDialog();
            return;
        }
        Executor executor = getMainExecutor();
        CancellationSignal cancellationSignal = new CancellationSignal();
        BiometricPrompt.AuthenticationCallback callback = new BiometricPrompt.AuthenticationCallback() {
            @Override
            public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                super.onAuthenticationSucceeded(result);
                unlockAndLoad();
            }

            @Override
            public void onAuthenticationError(int errorCode, CharSequence errString) {
                super.onAuthenticationError(errorCode, errString);
                if (prefs.contains("pin_hash")) showPinDialog();
                else {
                    showingUnlock = false;
                    Toast.makeText(MainActivity.this, "No fue posible usar biometría.", Toast.LENGTH_SHORT).show();
                }
            }
        };
        try {
            BiometricPrompt prompt = new BiometricPrompt.Builder(this)
                    .setTitle("Violet Grape")
                    .setSubtitle("Desbloquea tu journal")
                    .setDescription("Tus registros permanecen guardados de forma local en este dispositivo.")
                    .setNegativeButton(prefs.contains("pin_hash") ? "Usar PIN" : "Cancelar", executor,
                            (dialogInterface, i) -> {
                                if (prefs.contains("pin_hash")) showPinDialog();
                                else showingUnlock = false;
                            })
                    .build();
            prompt.authenticate(cancellationSignal, executor, callback);
        } catch (Exception e) {
            if (prefs.contains("pin_hash")) showPinDialog();
            else {
                showingUnlock = false;
                unlockAndLoad();
            }
        }
    }

    private void showPinDialog() {
        runOnUiThread(() -> {
            final EditText input = new EditText(MainActivity.this);
            input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
            input.setHint("PIN");
            input.setTextSize(20f);
            input.setGravity(Gravity.CENTER);
            input.setPadding(28, 24, 28, 24);

            LinearLayout wrap = new LinearLayout(MainActivity.this);
            wrap.setOrientation(LinearLayout.VERTICAL);
            wrap.setPadding(48, 16, 48, 0);

            TextView subtitle = new TextView(MainActivity.this);
            subtitle.setText("Tu espacio privado 💜");
            subtitle.setTextSize(15f);
            subtitle.setTextColor(Color.rgb(108, 95, 121));
            subtitle.setGravity(Gravity.CENTER);
            subtitle.setPadding(0, 0, 0, 12);
            wrap.addView(subtitle);
            wrap.addView(input);

            AlertDialog dialog = new AlertDialog.Builder(MainActivity.this)
                    .setTitle("Violet Grape")
                    .setView(wrap)
                    .setCancelable(false)
                    .setPositiveButton("Entrar", null)
                    .setNegativeButton("Cerrar", (d, which) -> finish())
                    .create();
            dialog.setOnShowListener(d -> dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
                String pin = input.getText().toString();
                if (verifyPin(pin)) {
                    dialog.dismiss();
                    unlockAndLoad();
                } else {
                    input.setError("PIN incorrecto");
                }
            }));
            dialog.show();
            input.requestFocus();
        });
    }

    private boolean verifyPin(String pin) {
        try {
            String saltB64 = prefs.getString("pin_salt", null);
            String expected = prefs.getString("pin_hash", null);
            if (saltB64 == null || expected == null) return false;
            byte[] salt = Base64.decode(saltB64, Base64.NO_WRAP);
            String actual = hashPin(pin, salt);
            return MessageDigest.isEqual(expected.getBytes(StandardCharsets.UTF_8), actual.getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) {
            return false;
        }
    }

    private String hashPin(String pin, byte[] salt) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        digest.update(salt);
        digest.update(pin.getBytes(StandardCharsets.UTF_8));
        return Base64.encodeToString(digest.digest(), Base64.NO_WRAP);
    }

    private void setPinNative(String pin) throws Exception {
        if (pin == null || !pin.matches("\\d{4,8}")) throw new IllegalArgumentException("El PIN debe tener de 4 a 8 números.");
        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);
        prefs.edit()
                .putString("pin_salt", Base64.encodeToString(salt, Base64.NO_WRAP))
                .putString("pin_hash", hashPin(pin, salt))
                .apply();
    }

    private File dataFile() {
        return new File(getFilesDir(), DATA_FILE);
    }

    private synchronized String readDataFile() {
        File f = dataFile();
        if (!f.exists()) return "";
        try (FileInputStream in = new FileInputStream(f)) {
            byte[] bytes = new byte[(int) f.length()];
            int total = 0;
            while (total < bytes.length) {
                int n = in.read(bytes, total, bytes.length - total);
                if (n < 0) break;
                total += n;
            }
            return new String(bytes, 0, total, StandardCharsets.UTF_8);
        } catch (Exception e) {
            return "";
        }
    }

    private synchronized boolean writeDataFile(String json) {
        try {
            new JSONObject(json); // Reject malformed backup/state.
            File temp = new File(getFilesDir(), DATA_FILE + ".tmp");
            try (FileOutputStream out = new FileOutputStream(temp, false)) {
                out.write(json.getBytes(StandardCharsets.UTF_8));
                out.getFD().sync();
            }
            File target = dataFile();
            if (target.exists() && !target.delete()) return false;
            return temp.renameTo(target);
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == REQ_EXPORT) {
            try (OutputStream out = getContentResolver().openOutputStream(uri, "w")) {
                if (out != null && pendingExportJson != null) {
                    out.write(pendingExportJson.getBytes(StandardCharsets.UTF_8));
                    out.flush();
                    Toast.makeText(this, "Copia guardada 💜", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                Toast.makeText(this, "No pude guardar la copia.", Toast.LENGTH_SHORT).show();
            } finally {
                pendingExportJson = null;
            }
        } else if (requestCode == REQ_IMPORT) {
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                if (in == null) return;
                BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) sb.append(line).append('\n');
                String json = sb.toString().trim();
                new JSONObject(json);
                String quoted = JSONObject.quote(json);
                webView.evaluateJavascript("window.VioletApp && window.VioletApp.importBackup(" + quoted + ")", null);
            } catch (Exception e) {
                Toast.makeText(this, "Ese archivo no parece ser una copia de Violet Grape.", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        pausedAt = System.currentTimeMillis();
        if (webView != null) webView.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null && appUnlocked) webView.onResume();
        if (appUnlocked && hasLockConfigured() && pausedAt > 0 && System.currentTimeMillis() - pausedAt > 30_000L) {
            showUnlockFlow();
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && appUnlocked) {
            webView.evaluateJavascript("window.VioletApp && window.VioletApp.handleBack ? window.VioletApp.handleBack() : false", value -> {
                if (!"true".equals(value)) MainActivity.super.onBackPressed();
            });
        } else {
            super.onBackPressed();
        }
    }

    public final class NativeBridge {
        private final Context context;
        NativeBridge(Context context) { this.context = context; }

        @JavascriptInterface
        public String loadData() { return readDataFile(); }

        @JavascriptInterface
        public boolean saveData(String json) { return writeDataFile(json); }

        @JavascriptInterface
        public boolean hasPin() { return prefs.contains("pin_hash"); }

        @JavascriptInterface
        public String setPin(String pin) {
            try {
                setPinNative(pin);
                return "ok";
            } catch (Exception e) {
                return e.getMessage() == null ? "No fue posible guardar el PIN." : e.getMessage();
            }
        }

        @JavascriptInterface
        public void clearPin() {
            prefs.edit().remove("pin_hash").remove("pin_salt").apply();
        }

        @JavascriptInterface
        public boolean isBiometricEnabled() { return prefs.getBoolean("biometric_enabled", false); }

        @JavascriptInterface
        public boolean biometricSupported() {
            return Build.VERSION.SDK_INT >= Build.VERSION_CODES.P &&
                    (getPackageManager().hasSystemFeature("android.hardware.fingerprint") ||
                     getPackageManager().hasSystemFeature("android.hardware.biometrics.face") ||
                     getPackageManager().hasSystemFeature("android.hardware.biometrics.iris"));
        }

        @JavascriptInterface
        public void setBiometricEnabled(boolean enabled) {
            prefs.edit().putBoolean("biometric_enabled", enabled).apply();
        }

        @JavascriptInterface
        public void exportBackup(String json) {
            try { new JSONObject(json); } catch (Exception e) { return; }
            pendingExportJson = json;
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, "violet-grape-backup.json");
                startActivityForResult(intent, REQ_EXPORT);
            });
        }

        @JavascriptInterface
        public void importBackup() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                startActivityForResult(intent, REQ_IMPORT);
            });
        }

        @JavascriptInterface
        public void openBiometricSettings() {
            runOnUiThread(() -> {
                try {
                    Intent intent;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        intent = new Intent(Settings.ACTION_BIOMETRIC_ENROLL);
                    } else {
                        intent = new Intent(Settings.ACTION_SECURITY_SETTINGS);
                    }
                    startActivity(intent);
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface
        public String appVersion() { return "1.0.0"; }
    }
}
