package com.violetgrape.journal;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import java.util.Calendar;

public final class ReminderScheduler {
    public static final String CHANNEL_ID = "violet_grape_reminders";
    public static final String CHANNEL_NAME = "Recordatorios de Violet Grape";

    private ReminderScheduler() {}

    public static void ensureChannel(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    CHANNEL_NAME,
                    NotificationManager.IMPORTANCE_DEFAULT
            );
            channel.setDescription("Recordatorios personales configurados dentro de Violet Grape.");
            nm.createNotificationChannel(channel);
        }
    }

    private static int requestCode(String id, int dayOfWeek) {
        return (id + ":" + dayOfWeek).hashCode() & 0x7fffffff;
    }

    public static void schedule(Context context, String id, String title, String body,
                                int hour, int minute, int dayOfWeek) {
        if (dayOfWeek < Calendar.SUNDAY || dayOfWeek > Calendar.SATURDAY) return;
        AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarm == null) return;

        Calendar now = Calendar.getInstance();
        Calendar next = Calendar.getInstance();
        next.set(Calendar.SECOND, 0);
        next.set(Calendar.MILLISECOND, 0);
        next.set(Calendar.HOUR_OF_DAY, hour);
        next.set(Calendar.MINUTE, minute);

        int today = next.get(Calendar.DAY_OF_WEEK);
        int delta = (dayOfWeek - today + 7) % 7;
        if (delta == 0 && next.getTimeInMillis() <= now.getTimeInMillis()) delta = 7;
        next.add(Calendar.DAY_OF_YEAR, delta);

        Intent intent = new Intent(context, ReminderReceiver.class);
        intent.putExtra("id", id);
        intent.putExtra("title", title);
        intent.putExtra("body", body);
        intent.putExtra("hour", hour);
        intent.putExtra("minute", minute);
        intent.putExtra("day", dayOfWeek);

        PendingIntent pending = PendingIntent.getBroadcast(
                context,
                requestCode(id, dayOfWeek),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
        alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.getTimeInMillis(), pending);
    }

    public static void cancel(Context context, String id) {
        AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarm == null) return;
        for (int day = Calendar.SUNDAY; day <= Calendar.SATURDAY; day++) {
            Intent intent = new Intent(context, ReminderReceiver.class);
            PendingIntent pending = PendingIntent.getBroadcast(
                    context,
                    requestCode(id, day),
                    intent,
                    PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE
            );
            if (pending != null) {
                alarm.cancel(pending);
                pending.cancel();
            }
        }
    }
}
