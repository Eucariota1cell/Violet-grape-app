# Violet Grape 1.1

Journal personal Android, local y sin conexión.

## v1.1
- Nombre/apodo y frase amable en Inicio.
- Registro de medidas corporales con historial y comparación.
- Registro de actividad, duración e intensidad, con calorías manuales o estimadas.
- Recordatorios locales con notificaciones por día y hora.
- Firma de release preparada para actualizaciones futuras.

La clave de firma **no** debe subirse al repositorio. Se restaura en GitHub Actions mediante secrets.
