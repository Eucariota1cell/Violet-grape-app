package com.violetgrape.journal;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.nio.charset.StandardCharsets;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || !Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) return;
        ReminderScheduler.ensureChannel(context);
        try {
            File file = new File(context.getFilesDir(), "violet_grape_data.json");
            if (!file.exists()) return;
            byte[] bytes = new byte[(int) file.length()];
            try (FileInputStream in = new FileInputStream(file)) {
                int offset = 0;
                while (offset < bytes.length) {
                    int count = in.read(bytes, offset, bytes.length - offset);
                    if (count < 0) break;
                    offset += count;
                }
            }
            JSONObject state = new JSONObject(new String(bytes, StandardCharsets.UTF_8));
            JSONArray reminders = state.optJSONArray("reminders");
            if (reminders == null) return;
            for (int i = 0; i < reminders.length(); i++) {
                JSONObject r = reminders.optJSONObject(i);
                if (r == null || !r.optBoolean("enabled", true)) continue;
                String id = r.optString("id", "");
                String title = r.optString("title", "Violet Grape");
                String body = r.optString("body", "Un recordatorio que dejaste para ti 💜");
                int hour = r.optInt("hour", 9);
                int minute = r.optInt("minute", 0);
                JSONArray days = r.optJSONArray("days");
                if (days == null) continue;
                for (int j = 0; j < days.length(); j++) {
                    ReminderScheduler.schedule(context, id, title, body, hour, minute, days.optInt(j, 2));
                }
            }
        } catch (Exception ignored) {}
    }
}
